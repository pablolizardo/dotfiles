# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

bl_info = {
    "name": "Animated Number",
    "author": "Michael Soluanov",
    "version": (0, 1, 0),
    "blender": (2, 71, 0),
    "location": "Properties > Text data",
    "description": "Replace text block with number, that can be animated",
    "category": "Object"}
    
import bpy


class Aninum_Panel(bpy.types.Panel):
    bl_label = "Animated Number"
    bl_idname = "Aninum_Panel"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "data"
    bl_property_type = bpy.types.Lamp
    
    bpy.types.Object.aninum_pos=bpy.props.FloatProperty( name="Show number", default=1 )
    bpy.types.Object.aninum_digits_after=bpy.props.IntProperty( name="Digits after dot", default=2, min=0, max=10 )
    bpy.types.Object.aninum_active=bpy.props.BoolProperty( name="Active", default=False )
    
    @classmethod
    def poll(cls, context):
        return (context.object.type=='FONT')
    
    def draw_header(self, context):
        layout = self.layout
        activ=context.active_object
        layout.prop(activ, "aninum_active", text="")
    
    def draw(self, context):
        layout = self.layout
        activ=context.active_object
        
        if(activ.aninum_active):
            
            row = layout.row()
            row.prop(activ, "aninum_pos")
            row.prop(activ, "aninum_digits_after")
        

def textupdate_handler(scene):
    
    for txt in scene.objects:
        if (txt.type=='FONT'):
            if (txt.aninum_active):
                frame = (txt.aninum_pos)
                digitsafter=txt.aninum_digits_after
                if(digitsafter==0):
                    txt.data.body=str(int(frame))
                else:
                    txt.data.body=str(round(frame,digitsafter))
 
 
def register():
    bpy.utils.register_class(Aninum_Panel)
    bpy.app.handlers.scene_update_pre.append(textupdate_handler)
    bpy.app.handlers.scene_update_post.append(textupdate_handler)
    
def unregister():
    bpy.utils.unregister_class(Aninum_Panel)
    bpy.app.handlers.scene_update_pre.remove(textupdate_handler)
    bpy.app.handlers.scene_update_post.remove(textupdate_handler)

if __name__ == "__main__":
    register()



